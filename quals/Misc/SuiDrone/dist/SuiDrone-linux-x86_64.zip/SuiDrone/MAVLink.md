# MAVLink data sheet

Reference: [MAVLink common messages](https://mavlink.io/en/messages/common.html).

| Field | Value |
|---|---|
| Command endpoint | UDP `127.0.0.1:14560` |
| Telemetry destination | UDP `127.0.0.1:14550` after the game receives a loopback MAVLink datagram from your client |
| Target system/component | `42` / `1` (broadcast `0` accepted) |
| Coordinate frame | `MAV_FRAME_LOCAL_NED` = `1` |
| Coordinates | `x=north`, `y=east`, `z=down`; altitude 3.2 m is `z=-3.2` |

| Message | ID | Accepted data |
|---|---:|---|
| `HEARTBEAT` | 0 | telemetry/discovery |
| `SET_MODE` | 11 | custom-mode flag required; `6=OFFBOARD`, `4=HOLD` |
| `LOCAL_POSITION_NED` | 32 | telemetry at 10 Hz |
| `COMMAND_LONG` | 76 | `400` arm/disarm; `176` mode; `22` takeoff |
| `COMMAND_ACK` | 77 | command result |
| `SET_POSITION_TARGET_LOCAL_NED` | 84 | position setpoint only |
| `POSITION_TARGET_LOCAL_NED` | 85 | active target at 10 Hz |
| `STATUSTEXT` | 253 | rejection/status text |

`SET_POSITION_TARGET_LOCAL_NED` requirements:

| Field | Value |
|---|---|
| `coordinate_frame` | `1` |
| `type_mask` | `3576` (`0x0DF8`) |
| Update rate | approximately 5 Hz |
| Gateway maximum | 20 control messages/s |
| Setpoint timeout | 2 s → HOLD |
| Horizontal leg | ≤ 10.5 m from current drone position |
| Vertical increment | ≤ 3 m from current drone position |
| Altitude | 0.8–6 m |
| Wall clearance | route leg must not cross a maze wall |

Objective data: after MAVLink takeover, reach horizontal distance ≤4 m from
`N=0, E=0`; altitude 1.5–4 m; speed ≤0.5 m/s; continuous hold ≥4 s.

# SuiDrone world artwork

## Vehicle

**Car Kit / delivery vehicle**, Kenney, CC0 1.0.
Source: https://kenney.nl/assets/car-kit
License: https://creativecommons.org/publicdomain/zero/1.0/
Original notice: `licenses/Kenney.txt` in the player distribution.

## Quadcopter and propellers

Copyright (c) 2022, Rudis Laboratories. All rights reserved.
Source: https://github.com/PX4/PX4-gazebo-models/tree/5577035667afb4b63fe1f966fb1a58bbb05d905b/models/x500_base

## Tiled surface materials

- https://ambientcg.com/view?id=Ground037
- https://ambientcg.com/view?id=Bricks059
- https://ambientcg.com/view?id=Wood051
- https://ambientcg.com/view?id=Metal032
- License: https://creativecommons.org/publicdomain/zero/1.0/

The X500 carbon-fiber texture is distributed under the model's BSD notice.

# SuiDrone world artwork

These assets are bundled locally. No download, account, or remote asset API is
required to play. Asset creators do not endorse SuiDrone.

## Vehicle

**Car Kit / delivery vehicle**, Kenney, CC0 1.0.
Source: https://kenney.nl/assets/car-kit
License: https://creativecommons.org/publicdomain/zero/1.0/
Original notice: `licenses/Kenney.txt` in the player distribution.
Adaptations: geometry converted from glTF, palette baked to vertex colors,
olive repaint, rescaled, and combined with original SuiDrone workshop fittings.

## Quadcopter and propellers

**X500 base model**, Rudis Laboratories / PX4 Gazebo Models, BSD 3-Clause.
Copyright (c) 2022, Rudis Laboratories. All rights reserved.
Source: https://github.com/PX4/PX4-gazebo-models/tree/5577035667afb4b63fe1f966fb1a58bbb05d905b/models/x500_base
Full required notice: `licenses/PX4-X500.txt` in the player distribution.
Adaptations: coordinate/scale conversion; decimation; material colors adapted;
source motor and propeller geometry assembled and animated by the renderer.
Original SuiDrone additions: chamfered avionics cover, retaining straps and survey
camera. CAD seam vertices are welded before simplification to preserve the frame.
This is use of the **visual assets only**, not introduction of PX4/Gazebo runtime
or physical-device control. Separate trademark/logo decals are not included.

## Tiled surface materials

**Ground037**, **Bricks059**, **Wood051**, **Metal032**, ambientCG / Lennart Demes,
CC0 1.0. Unmodified 1K JPG color, OpenGL normal and roughness maps.

- https://ambientcg.com/view?id=Ground037
- https://ambientcg.com/view?id=Bricks059
- https://ambientcg.com/view?id=Wood051
- https://ambientcg.com/view?id=Metal032
- License: https://creativecommons.org/publicdomain/zero/1.0/

The X500 carbon-fiber texture is distributed under the model's BSD notice.
Runtime lighting/UV tiling changes their appearance without editing the source maps.

## Reproducibility

Organizer source: `assets/vendor/manifest.json` records acquisition URLs, licenses
and SHA-256 checksums. `scripts/fetch_art.py` downloads selected files;
`scripts/prepare_art.py` converts them to SDM1 using the pinned art-tool requirements.
`assets/world/meshes.json` records output triangle counts and checksums.
The original archives and CAD sources are not shipped in the player ZIP.

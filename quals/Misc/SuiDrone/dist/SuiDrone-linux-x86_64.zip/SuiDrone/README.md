# SuiDrone

Extract the archive into a writable directory. On Linux, `chmod +x suidrone`
if your unzip utility discarded executable permissions, then `./suidrone`.
On Windows, run `suidrone.exe` from PowerShell. An OpenGL-capable desktop is required.

Practice is offline. For competition, use the per-team instance address shown by GZCTF:

```
./suidrone --server http://INSTANCE_IP:PORT --allow-insecure-http
```

Each DynamicContainer is already assigned to one team. No token, account
credential, or browser session is needed by the client. The game registers an
attempt before flight and contacts that same instance at completion. Submit the
returned flag to GZCTF normally.

Tab opens SuiNav. Click to inspect coordinates; M measures two points; P places
your own waypoints. Right-drag pans; wheel zooms. Export CSV saves only your
chosen points. Red route segments warn about walls or excessive MAVLink legs.
H opens help; Escape closes panels; C changes camera; arrows orbit the camera;
R resets flight; F5 retries completion. There is no keyboard drone flight.
T focuses the workshop; the wheel zooms the 3D camera. F8 toggles balanced/native
world resolution; UI and SuiNav always remain full resolution. The imported truck,
quadcopter and material credits are in ART-CREDITS.md, with licenses included.

Write your own MAVLink client. SuiNav exports only the points you select; no
control script, route solver, Python dependency bundle, or hidden route data is
included. `MAVLink.md` is the compact protocol data sheet. The verifier
re-simulates your recorded MAVLink inputs; editing a local success indicator or
sending a claimed position does not prove completion.

Study the visible maze and write your own route planner or manually survey it.
Take over with MAVLink, respect walls and leg limits, then hold the target steadily.
The server re-simulates your recorded MAVLink controls; editing a local success
indicator or sending a claimed position does not prove completion.

Keep `flight.json` and `attempt.json` if interrupted. Restart with the same
competition arguments plus `--resume`. Attempts last four hours. Practice
recordings cannot be redeemed as competition attempts.

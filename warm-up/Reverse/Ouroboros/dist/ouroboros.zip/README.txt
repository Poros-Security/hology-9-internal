ouroboros

  python ouroboros.pyc

then paste the flag on stdin.

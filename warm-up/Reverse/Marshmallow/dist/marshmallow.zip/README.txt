Feed me the flag.

  python marshmallow.pyc <flag>

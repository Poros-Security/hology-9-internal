<?php

$SECRET_FLAG = "FLAG";
